
import os
import logging
import telegram
from telegram.ext import Updater, CommandHandler, CallbackContext
from telegram import Update
from datetime import datetime

# Налаштування логування
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# Отримуємо токен і ID
TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

def send_daily_message(context: CallbackContext):
    # Тут може бути парсинг або API-запит
    message = (
        "Топ матчі дня для ставок:
"
        "1. Арсенал – ПСЖ (ЛЧ)
"
        "   Найпопулярніша ставка: Обидві заб'ють – 1.78
"
        "2. Реал – Ман Сіті (ЛЧ)
"
        "   Найпопулярніша ставка: П2 – 2.45"
    )
    context.bot.send_message(chat_id=CHAT_ID, text=message)

def start(update: Update, context: CallbackContext):
    update.message.reply_text("Бот для щоденних ставок активований!")

def main():
    updater = Updater(token=TOKEN)
    dispatcher = updater.dispatcher

    dispatcher.add_handler(CommandHandler("start", start))

    job_queue = updater.job_queue
    job_queue.run_daily(send_daily_message, time=datetime.strptime("10:00", "%H:%M").time())

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
